import {
  registerPlugin
} from "./chunk-KILKDVRJ.js";
import "./chunk-QHQP2P2Z.js";

// node_modules/@capacitor/preferences/dist/esm/index.js
var Preferences = registerPlugin("Preferences", {
  web: () => import("./web-WGOQMVEB.js").then((m) => new m.PreferencesWeb())
});
export {
  Preferences
};
//# sourceMappingURL=@capacitor_preferences.js.map
